/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function( config ){
config.filebrowserBrowseUrl = 'http://localhost/believe/kcfinder/browse.php?type=files';
config.filebrowserImageBrowseUrl = 'http://localhost/believe/kcfinder/browse.php?type=images';
config.filebrowserFlashBrowseUrl = 'http://localhost/believe/kcfinder/browse.php?type=flash';
config.filebrowserUploadUrl = 'http://localhost/believe/kcfinder/upload.php?type=files';
config.filebrowserImageUploadUrl = 'http://localhost/believe/kcfinder/upload.php?type=images';
config.filebrowserFlashUploadUrl = 'http://localhost/believe/kcfinder/upload.php?type=flash';
};
